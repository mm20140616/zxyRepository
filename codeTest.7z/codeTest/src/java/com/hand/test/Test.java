package com.hand.test;

public class Test {

    public static void main(String[] args) {
        int i = 96;
        System.out.println(i/10);
    }
}
